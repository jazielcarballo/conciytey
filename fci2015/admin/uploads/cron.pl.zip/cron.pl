###############################################################################
# cron -- perl implementation of cron for NT/95
###############################################################################
#
# by Scott McMahan
# version 1.0 beta prerelease
#
# download the latest from http://www.megadodo.demon.co.uk/perl/index.html
# submit change proposals to bryn.truscott@tradepoint.co.uk
#
# Changes
# 29/04/98 BJT Added Silent mode to cut down screen logging
# 13/04/99 BJT Removed "start" from system() call, as this seemed to be
#              preventing batch files from executing
# 29Dec99 stv You can now use ranges in the date and time specifier fields,
#             e.g. 1-5 in the day-of-week field instead of 1,2,3,4,5.
#             However, I didn't implement cron's 24-hour wraparound, so you
#             can't for example use 23-1 in the hour field to get the two
#             hours around midnight.   stv@well.com
# 13Jan00 stv I moved the "what time is it now" code out of the "read
#             cronfile" loop, in case your cron task takes more than 1 min.
# 20Jan00 stv Y2K fixing.
#
###############################################################################

###############################################################################
# Usage: cron <crontab file>
#
# Where <crontab file> is a valid crontab file in the usual UNIX format.
# Defaults to file named "crontab" in current directory
###############################################################################
# There are some configuration options after the comments.
# They're probably okay as-is, but may be worth looking at.
###############################################################################

###############################################################################
# Author's Notes:
# Perl is obviously a prerequisite for using this program!
# I chose perl because it was trivial to implement the file parser.
# Just fire this up when you log in, and it'll keep running.
# Warning: this is not a complete implementation of cron!
# It's just the features I needed for my own task automation. It's about
# 86% authentic, when you discount the differences in starting it and
# security between UNIX and NT.
# I do not support:
#  - Daylight savings time (schedule stuff some other time besides
#    the overlap hour, or implement the logic and send me a copy!)
#  - embedded newlines in commands (run multiple commands from
#    a script and run the script from cron)
#  - usage is different (on the command line, a crontab file is
#    specified or the default "crontab" in the current directory
#    is opened)
#  - no security or allow/deny stuff (this cron assumes you're
#    running from a single logged-on NT account)
#
# Wish list:
#  [X] Support for ranges would be nice
#  [ ] DST logic
#  [ ] In-crontab "pragmas" or command line switches for log file
#      and logging level
#  [X] Leading 0 logic for date/times -- I wrote this once and will
#      have to find it
#  
# Known Problems
#
# Noted by Steve Vance (stv@well.com):
# The script does a "sleep 60" after each cron check. Since the opening 
# and reading of the crontab file takes some time, a cron cycle will 
# occasionally start in one minute and finish in the next.  For example, 
# say the program wakes up at 07:29:55, reads the crontab file (and
# does all 07:29 tasks), then goes to sleep for 60 seconds at 07:30:05.  It
# will not awaken again until 07:31:05, skipping all 7:30 tasks!  The best
# fix would probably be to check the time again before going to sleep, see how
# many seconds until the next cron minute (if any) and sleeping only for
# that many seconds (if at all). (Alternatively the "start" command could be 
# replaced in the system call so that the script does not wait for jobs to 
# finish. However this seems to give problems when calling batch files - see
# change history, above.)
# 
###############################################################################

###############################################################################
# If you're not familiar with crontab files, they have lines
# with the following:
#
# min hour monthday month weekday command
#
#  - Lines beginning with '#' are comments and are ignored.
#  - The numeric entries can be separated by commas -- eg 1,2,3
#  - Ranges for each are as follows:
#           minute (0-59),
#           hour (0-23),
#           day of the month (1-31),
#           month of the year (1-12),
#           day of the week (0-6 with 0=Sunday).
###############################################################################

###############################################################################
# configuration section
###############################################################################

# Note there are two levels of logging: normal logging, controlled by
# the logfile variable, logs all commands executed and when they're
# executed. The message facility prints messages about everything that
# the program does, and is sent to the screen unless the msgfile
# variable is set. Use the msgfile only in emergencies, as voluminous
# output is generated (so much so that leaving msgfile active all night
# could exhaust available disk space on all but the most capacious
# systems) -- its primary purpose is for emergency debugging.
# Due to the peculiar construction of the log functions, the log and
# msg files can be the same file. This may or may not be good.
#
# There is now a third level: setting $silent to 1, means that the screen
# just displays the same activity messages as the log file.

$silent = 1 ;
$logfile = "cronlog.txt";
$msgfile = ""; # assign this only in emergency

# end of configuration

###############################################################################
# in_csl searches for an element in a comma separated list
###############################################################################

sub in_csl {
    ($what, $csl) = @_;
    MSG("Processing CSL");
    @a = split(/,/, $csl);
    @b = ();
    map {
        if (/(\d+)-(\d+)/) {
            push @b,$1..$2;
        } else {
            push @b,$_;
        }
    } @a;
    for $x (@b) {
        MSG("is $what equal to item $x?");
        if ($what eq $x) {
            return 1;
        }
    }
    return 0;
}

###############################################################################
# main program
###############################################################################

if (defined $ARGV[0]) {
    ACT("using $ARGV[0] as crontab file\n");
    $crontab = $ARGV[0];
}
else {
    ACT("using default file crontab\n");
    $crontab = "crontab";
}

while (1) {

    open(F, "$crontab") or die "Can't open crontab; file $crontab: $!\n";
    $line = 0;

    # mon = 0..11 and wday = 0..6
    ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) =
        localtime(time);
    $mon++; # to get it to agree with the cron syntax
    $year %= 100;   # Y2K fix

    while (<F>) {
       $line++;

       if (/^$/) {
        MSG("blank line $line");
        next;
       }

       if (/^#/) {
        MSG("comment on line $line");
        next;
       }

       ($tmin, $thour, $tmday, $tmon, $twday, $tcommand) = split(/ +/, $_, 6);

       MSG("it is now $hour:$min:$sec on $mon/$mday/$year wday=$wday");
       MSG("should we do $thour:$tmin on $tmon/$tmday/--, wday=$twday?");

       $do_it = 0; # assume don't do it until proven otherwise

       # do it -- this month?
       if ( ($tmon eq "*") || ($mon == $tmon) || &in_csl($mon, $tmon)) {
           $do_it = 1;
           MSG("the month is valid");
       }
       else {
           $do_it = 0;
           MSG("cron: the month is invalid");
       }

       # do it -- this day of the month?
       if ( $do_it && ( ($tmday eq "*")
            || ($mday == $tmday) || &in_csl($mday, $tmday)) ) {
           $do_it = 1;
           MSG("the day of month is valid");
       }
       else {
           $do_it = 0;
           MSG("the day of month is invalid");
       }

       # do it -- this day of the week?
       if ( $do_it && ( ($twday eq "*")
            || ($wday == $twday) || &in_csl($wday, $twday)) ) {
           $do_it = 1;
           MSG("the day of week is valid");
       }
       else {
           $do_it = 0;
           MSG("the day of week is invalid");
       }

       # do it -- this hour?
       if ( $do_it && ( ($thour eq "*") ||
            ($hour == $thour)|| &in_csl($hour, $thour) ) ) {
           $do_it = 1;
           MSG("the hour is valid");
       }
       else {
           $do_it = 0;
           MSG("the hour is invalid");
       }

       # do it -- this minute?
       if ( $do_it && ( ($tmin eq "*") ||
            ($min == $tmin) || &in_csl($min, $tmin) ) ) {
           $do_it = 1;
           MSG("the min is valid");
       }
       else {
           $do_it = 0;
           MSG("the minute is invalid");
       }

       if ($do_it) {
           chop $tcommand;
           ACT("executing command <$tcommand>");
           system ("$tcommand");
#        system ("start $tcommand");
       }
    }

    close(F);
    MSG("***-----***");
    sleep(60);
}

exit;


###############################################################################
# Log activity
###############################################################################

sub ACT {
    # mon = 0..11 and wday = 0..6
    ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) =
    localtime(time);
    $mon++; # to get it to agree with the cron syntax
    $year %= 100;   # Y2K fix

    printf "cron*[%02d/%02d/%02d %02d:%02d]: @_\n", $mon,$mday,$year,$hour,$min;

    # since we're appending the log, always open it only as little
    # as necessary, so if we crash the info will be there
    open(LOGFILE, ">>$logfile") or return;
    printf LOGFILE "cron*[%02d/%02d/%02d %02d:%02d]: @_\n", $mon,$mday,$year,$hour,$min;
    close(LOGFILE);
}

###############################################################################
# routine to log messages
# logs to screen unless $silent is 1. If $msgfile is set to a filename, screen
# output also goes to that file
###############################################################################

sub MSG {
    return if $silent ;

    # mon = 0..11 and wday = 0..6
    ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) =
    localtime(time);
    $mon++; # to get it to agree with the cron syntax
    $year %= 100;   # Y2K fix

    printf "cron*[%02d/%02d/%02d %02d:%02d]: @_\n", $mon,$mday,$year,$hour,$min;

    return unless $msgfile;

    # since we're appending the log, always open it only as little
    # as necessary, so if we crash the info will be there
    open(LOGFILE, ">>$logfile") or return;
    printf LOGFILE "cron*[%02d/%02d/%02d %02d:%02d]: @_\n", $mon,$mday,$year,$hour,$min;
    close(LOGFILE);

}
